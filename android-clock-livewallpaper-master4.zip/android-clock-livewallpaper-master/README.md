Android Clock Live Wallpaper
===========================

This is the code source for Clock Live Wallpaper application used in an Android tutorial.

The tutorial video is available here on Youtube : https://www.youtube.com/watch?v=JrqN83cVHRU

Clock Live Wallpaper is also published on Google Play Store : https://play.google.com/store/apps/details?id=com.ssaurel.clocklw



![Screenshot](https://github.com/ssaurel/android-clock-livewallpaper/blob/master/screenshot.png)
